Script Created by DemonSad And DroogXK

Hour : 07:04

Day : December 13, 2019

Brazilian Hackers

Message : Beta Version Released

Twitter DemonSad : https://twitter.com/Magnus_Security

Twitter DroogXK : https://twitter.com/DroogXk
